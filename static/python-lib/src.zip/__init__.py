"""
双色彩预测平台 - browser-side 算法包 (Pyodide 用).

注意: 这个 __init__.py 只暴露浏览器需要的算法类 + api_* 桥接函数,
      不 import .crawler / .cache (这些是 Flask 后端专用, 浏览器跑不了).
      analyzer.py 是 browser 版本, 仅依赖 collections + typing + datetime.
"""
from .algorithms import (
    BaseAlgorithm,
    WeightedRandomAlgorithm,
    NormalDistributionAlgorithm,
    GeneticAlgorithm,
    MonteCarloAlgorithm,
    ComprehensiveAlgorithm,
    SmartRecommendationAlgorithm,
    ZoneDistributionAlgorithm,
    ConsecutiveAnalysisAlgorithm,
    SameTailAnalysisAlgorithm,
    PrimeCompositeAlgorithm,
    BigSmallAnalysisAlgorithm,
    MarkovChainAlgorithm,
    KMeansClusteringAlgorithm,
)

# analyzer 是 browser 版本, 不依赖 backend .cache
from .analyzer import Analyzer

# ============================================================
# api_* 桥接函数 - 浏览器 IndexedDB → Python Analyzer → JS
# pyBridge.api('get_statistics', {history: [...]}) 调用
# ============================================================

def api_get_statistics(history=None):
    """从 JS 传入 history, 运行 Analyzer, 返回统计 dict.

    pyBridge.api('get_statistics', {history: data})
    """
    if not history:
        return {
            'hot_numbers': {'overall': [], 'recent': [], 'stats': {}, 'recent_stats': {}},
            'cold_numbers': {'numbers': [], 'stats': {}},
            'missing_stats': {},
            'odd_even': {},
            'sum_analysis': {},
            'blue_ball': {'hot_numbers': [], 'cold_numbers': [], 'odd_even': {}, 'big_small': {}},
            'consecutive': {},
            '_empty': True
        }
    analyzer = Analyzer(history)
    return {
        'hot_numbers': analyzer.get_hot_numbers(),
        'cold_numbers': analyzer.get_cold_numbers(),
        'missing_stats': analyzer.get_missing_stats(),
        'odd_even': analyzer.get_odd_even_ratio(),
        'sum_analysis': analyzer.get_sum_analysis(),
        'blue_ball': analyzer.get_blue_ball_analysis(),
        'consecutive': analyzer.get_consecutive_numbers_analysis(),
    }


def api_get_analysis(history=None):
    """返回综合分析 (前端"数据分析"页用)."""
    return api_get_statistics(history)


def api_predict(history=None, algorithm='comprehensive', generations=5):
    """根据 history 用算法预测."""
    if not history:
        return {'success': False, 'message': '暂无历史数据', 'numbers': []}

    algo_map = {
        'comprehensive': ComprehensiveAlgorithm,
        'weighted_random': WeightedRandomAlgorithm,
        'normal_distribution': NormalDistributionAlgorithm,
        'genetic': GeneticAlgorithm,
        'monte_carlo': MonteCarloAlgorithm,
        'smart_recommendation': SmartRecommendationAlgorithm,
        'zone_distribution': ZoneDistributionAlgorithm,
        'consecutive_analysis': ConsecutiveAnalysisAlgorithm,
        'same_tail_analysis': SameTailAnalysisAlgorithm,
        'prime_composite': PrimeCompositeAlgorithm,
        'big_small_analysis': BigSmallAnalysisAlgorithm,
        'markov_chain': MarkovChainAlgorithm,
        'kmeans_clustering': KMeansClusteringAlgorithm,
    }
    cls = algo_map.get(algorithm, ComprehensiveAlgorithm)
    try:
        algo = cls(history, generations=generations)
        numbers = algo.predict()
        return {'success': True, 'numbers': numbers, 'algorithm': algorithm}
    except Exception as e:
        return {'success': False, 'message': str(e), 'numbers': []}


def api_check_numbers(history=None, red_balls=None, blue_ball=None):
    """检查指定号码在历史中的命中情况."""
    if not history or not red_balls or blue_ball is None:
        return {'success': False, 'message': '参数不完整', 'hit': False, 'count': 0}

    hit_count = 0
    hit_periods = []
    for record in history:
        if (record.get('red_balls') == red_balls and
            record.get('blue_ball') == blue_ball):
            hit_count += 1
            hit_periods.append(record.get('issue'))

    return {
        'success': True,
        'hit': hit_count > 0,
        'count': hit_count,
        'hit_periods': hit_periods[:10],  # 最近 10 个
        'red_balls': red_balls,
        'blue_ball': blue_ball,
    }


__all__ = [
    'BaseAlgorithm',
    'WeightedRandomAlgorithm',
    'NormalDistributionAlgorithm',
    'GeneticAlgorithm',
    'MonteCarloAlgorithm',
    'ComprehensiveAlgorithm',
    'SmartRecommendationAlgorithm',
    'ZoneDistributionAlgorithm',
    'ConsecutiveAnalysisAlgorithm',
    'SameTailAnalysisAlgorithm',
    'PrimeCompositeAlgorithm',
    'BigSmallAnalysisAlgorithm',
    'MarkovChainAlgorithm',
    'KMeansClusteringAlgorithm',
    'Analyzer',
    'api_get_statistics',
    'api_get_analysis',
    'api_predict',
    'api_check_numbers',
]